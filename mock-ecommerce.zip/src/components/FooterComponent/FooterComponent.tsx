import React from "react";

const FooterComponent = () => {
  return <div>Footer Component</div>;
};

export default FooterComponent;

import React from "react";

const MapPage = () => <div>Map Page</div>;

export default MapPage;

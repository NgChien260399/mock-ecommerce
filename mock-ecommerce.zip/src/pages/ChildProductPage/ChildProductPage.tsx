import React from "react";

const ChildProductPage = () => <div>Child Product Page</div>;

export default ChildProductPage;

import React from "react";

const WomenProductPage = () => <div>Women Product page</div>;

export default WomenProductPage;

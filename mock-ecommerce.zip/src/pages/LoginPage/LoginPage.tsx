import React from "react";

const LoginPage = () => <div>Login Page</div>;

export default LoginPage;

import React from "react";

const OrderPage = () => <div>Order Page</div>;

export default OrderPage;

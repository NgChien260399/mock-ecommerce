import React from "react";

const MenProductPage = () => <div>Men Product Page</div>;

export default MenProductPage;
